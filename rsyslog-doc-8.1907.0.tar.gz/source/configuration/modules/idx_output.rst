Output Modules
--------------

Output modules process messages. With them, message formats can be
transformed and messages be transmitted to various different targets.
They are generally defined via :doc:`action <../actions>` configuration
objects.

.. toctree::
   :glob:
   :maxdepth: 1

   om*
   sigprov_gt
   sigprov_ksi
   sigprov_ksi12
