Global Configuration Reference
==============================

