Queues: prepare for the worst
=============================


What are queues?
----------------

In-memory queues
^^^^^^^^^^^^^^^^

Disk queues
^^^^^^^^^^^

Disk-assisted queues
^^^^^^^^^^^^^^^^^^^^


Main message queue
------------------

Action queues
-------------

