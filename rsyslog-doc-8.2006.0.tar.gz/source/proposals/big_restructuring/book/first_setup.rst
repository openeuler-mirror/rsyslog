Create your first Rsyslog setup
===============================

Teach how to get log messages from `logger` command and write to files conditionally.


