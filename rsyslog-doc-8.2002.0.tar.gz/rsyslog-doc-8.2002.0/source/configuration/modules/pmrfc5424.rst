pmrfc5424: Parse RFC5424-formatted messages
===========================================

This is the new Syslog Standard.

:rfc:`5424`
