#!/bin/bash
export USE_VALGRIND="YES"
source ${srcdir:-.}/clickhouse-load.sh
