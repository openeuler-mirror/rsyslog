#!/bin/bash
# added 2015-10-30 by singh.janmejay
# This file is part of the rsyslog project, released under ASL 2.0
export USE_VALGRIND="YES"
source ${srcdir:-.}/array_lookup_table.sh
