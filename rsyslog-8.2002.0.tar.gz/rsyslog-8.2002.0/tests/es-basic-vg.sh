#!/bin/bash
export USE_VALGRIND="YES"
source ${srcdir:=.}/es-basic.sh
