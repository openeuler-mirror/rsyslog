#!/bin/bash
export USE_VALGRIND="YES"
source ${srcdir:-.}/clickhouse-bulk-load.sh
