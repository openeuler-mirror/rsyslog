#!/bin/bash
export USE_VALGRIND="YES"
source ${srcdir:-.}/clickhouse-basic.sh
