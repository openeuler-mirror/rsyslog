#!/bin/bash
# added 2019-04-12 by Rainer Gerhards, released under ASL 2.0
export USE_VALGRIND="YES"
source ${srcdir:=.}/dnscache-TTL-0.sh
