#!/bin/bash
# addd 2020-01-19 by RGerhards, released under ASL 2.0
export USE_VALGRIND="YES"
source ${srcdir:=.}/fac_local0.sh
