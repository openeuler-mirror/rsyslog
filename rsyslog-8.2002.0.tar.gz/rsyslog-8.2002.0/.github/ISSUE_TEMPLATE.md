### Expected behavior

### Actual behavior

### Steps to reproduce the behavior

### Environment
- rsyslog version: <!-- e.g. 8.35.0 - use "rsyslogd -v" to obtain the version number -->
- platform: <!-- e.g. Ubuntu 16.04 -->
- for configuration questions/issues, include rsyslog.conf and included config files

<!-- Note: rsyslog documentation is available here:
  - current stable release: http://www.rsyslog.com/doc/v8-stable/
  - pre-release: http://www.rsyslog.com/doc/master/
-->
