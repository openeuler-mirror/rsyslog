Proposals
=========

.. toctree::
   :maxdepth: 2
   
   version_naming
   lookup_tables
   big_restructuring/index
